import os.path

import db
import Generation.generate as gen
import Generation.question as question
import systemhealth
import Generation.textwork as tw

queue = 0
def set_queue(status: int):
    global queue
    queue = status


def response(meta: bool = False, error: int = 0, description: str = 'no description', info: dict = {}) -> dict:
    '''Генерирует ответ сервера пользователю'''
    return {'meta': {'status': meta, 'error': error, 'description': description}, 'info': info}

def check_systemhealth(token):
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        image_status, gpt_status = systemhealth.check_system()
        return response(True, 0, 'Succesfull!', {'image_status': image_status, 'gpt_errors': gpt_status})
    else:
        return response(False, 104, 'Token not found')

def user(do: str, name: str = '', token: str = None, password: str = None, validate: str = None) -> dict:
    '''Действия с аккаунтом'''
    # Регистрация
    if do == 'register':
        if password != validate:
            return response(False, 100, 'Password and validate failed')

        status = db.reg_user(name, password)
        if status == 'already exists':
            return response(False, 101, 'Change other username')

        return response(True, 0, 'Registration succesfull')
    # Авторизация
    elif do == 'login':
        status = db.login_user(name, password)
        if status == 'incorrect password':
            return response(False, 102, 'Incorrect password')
        elif status == 'not found':
            return response(False, 103, 'User not found')
        return response(True, 0, 'Auth succesfull', status)
    # Метод получения статистики через api
    elif do == 'stats':
        status = db.get_stats(token)
        if status == 'invalid token':
            return response(False, 104, 'Token not found')
        return response(True, 0, 'Succesfull', status)
    else:
        return response(False, 1, 'Method not found')

def generate_presentation(token, theme: str = None, countslides: int = 5, name: str = '', add: str = None):
    global queue
    '''Генерация презентации'''
    if queue == 0:
        if db.add_stat(token, 'api_responses', 1) != 'invalid token':
            if countslides > 4:
                db.add_stat(token, 'presentations', 1)
                set_queue(1)
                status = gen.give_info(theme, countslides, name, add)
                if status == 'slides count error':
                    set_queue(0)
                    return response(False, 201, 'The number of slides exceeds the acceptable value')
                elif status == 'invalid structure':
                    set_queue(0)
                    return response(False, 202, 'An incorrect plan was received from ChatGPT. Try Again. Change the add parameter if it was used')
                else:
                    set_queue(0)
                    return response(True, 0, 'Generation succesfull',
                                    {'url': f'https://api-prbot.ru/download?presentation={theme}',
                                    'predurl': f'https://api-prbot.ru/view?presentation={theme}',
                                    'structure': f'https://api-prbot.ru/download?structure={theme}'})
            return response(False, 200, 'The number of slides is less than allowed value')
        return response(False, 104, 'Token not found')
    return response(False, 203, 'Generation is carried out to another user')

def generate_structure(token, theme: str = None, countslides: int = 5, name: str = '', add: str = None):
    '''Генерация структуры'''
    if queue == 0:
        if db.add_stat(token, 'api_responses', 1) != 'invalid token':
            if countslides > 4:
                set_queue(1)
                status = gen.give_info(theme, countslides, name, add)
                if status == 'slides count error':
                    set_queue(0)
                    return response(False, 201, 'The number of slides exceeds the acceptable value')
                elif status == 'invalid structure':
                    set_queue(0)
                    return response(False, 202, 'An incorrect plan was received from ChatGPT. Try Again. Change the add parameter if it was used')
                else:
                    set_queue(0)
                    return response(True, 0, 'Generation succesfull',
                                    {'structure': f'https://api-prbot.ru/download?structure={theme}'})
            return response(False, 200, 'The number of slides is less than allowed value')
        return response(False, 104, 'Token not found')
    return response(False, 203, 'Generation is carried out to another user')

def generation_time(token, countslides):
    '''Вычислить время генерации'''
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        if countslides < 5:
            return response(False, 200, 'The number of slides is less than allowed value')
        elif countslides > 15:
            return response(False, 201, 'The number of slides exceeds the acceptable value')
        return response(True, 0, 'Succesfull', {'time': str(countslides*8) + 's'})
    return response(False, 104, 'Token not found')

def get_presentation(token, theme):
    mainpath = ''
    '''Получить презентацию с сервера'''
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        if os.path.exists(f'{mainpath}Generation/presentations/{theme}') == False:
            return response(False, 300, 'File not found')
        return response(True, 0, 'Succesfull',
                                {'url': f'https://api-prbot.ru/download?presentation={theme}',
                                'predurl': f'https://api-prbot.ru/view?presentation={theme}',
                                'structure': f'https://api-prbot.ru/download?structure={theme}'})
    return response(False, 104, 'Token not found')

def ask(token, text):
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        text = question.ask_gpt(text)
        return response(True, 0, 'Succesfull!', {'text': text})
    else:
        return response(False, 104, 'Token not found')

def essay(token, theme, countwords, add: str = None):
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        text = question.essay(theme, countwords, add)
        return response(True, 0, 'Succesfull!', {'text': text})
    else:
        return response(False, 104, 'Token not found')

def abstract(token, theme):
    if db.add_stat(token, 'api_responses', 1) != 'invalid token':
        result = tw.abstract(theme)
        if result == True:
            return response(True, 0, 'Succesfull', {'url': f'https://api-prbot.ru/abstract?theme={theme}'})
        return response(False, 1, 'Unknown error')
    else:
        return response(False, 104, 'Token not found')
