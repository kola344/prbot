import os
import random
import string

mainpath = ''
#default = {name: name, password: password, token: token, apiresponses: count, presentations: count, allpresentations: [p1, p2]}
def generate_token(length: int) -> str:
    '''Генерирует токен'''
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.sample(letters_and_digits, length))

def token_to_name(token: str) -> str:
    '''Возвращает имя пользователя по токену'''
    name = eval(open(f'{mainpath}tokens.txt', 'r').read())[token]
    data = eval(open(f'{mainpath}users/{name}.txt', 'r').read())
    return data['name']

def check_token(token: str) -> bool:
    '''Проверяет правильность токена'''
    try:
        data = eval(open(f'{mainpath}tokens.txt').read())[token]
        return True
    except:
        return False


def check_user(name: str) -> bool:
    '''Проверяет, существует ли пользователь с таким именем'''
    return os.path.exists(f'{mainpath}users/{name}.txt')

def get_name(token: str) -> str:
    '''Возвращает имя пользователя по токену'''
    return eval(open(f'{mainpath}tokens.txt', 'r').read())[token]

def get_user(name: str) -> dict:
    '''Возвращает информацию о пользователе'''
    return eval(open(f'{mainpath}users/{name}.txt', 'r').read())

def check_pass(name: str, password: str = '') -> bool:
    '''Проверяет правильность пароля'''
    if get_user(name)['password'] == password:
        return True
    return False

def get_var(name: str, var: str):
    '''Возвращает значение переменной'''
    return get_user(name)[var]

def set_var(name: str, var: str, value):
    '''Устанавливает значение переменной'''
    with open(f'{mainpath}users/{name}.txt', 'r') as f:
        data = eval(f.read())
    data[var] = value
    with open(f'{mainpath}users/{name}.txt', 'w') as f:
        f.write(str(data))

def reg_user(name: str, password: str) -> str:
    '''Регистрирует нового пользователя'''
    token = generate_token(16)
    default = {'name': name, 'password': password, 'token': token, 'api_responses': 0, 'presentations': 0, 'allpresentations': []}
    if check_user(name) == True:
        return 'already exists'

    with open(f'{mainpath}users/{name}.txt', 'w') as f:
        f.write(str(default))
    with open(f'{mainpath}tokens.txt', 'r') as f:
        data = eval(f.read())
        data[token] = name
    with open(f'{mainpath}tokens.txt', 'w') as f:
        f.write(str(data))

    return 'ok'

def login_user(name: str, password: str):
    '''Возвращает данные пользователя'''
    if check_user(name) == True:
        if check_pass(name, password) == True:
            return get_user(name)
        return 'incorrect password'
    return 'not found'

def get_stats(token: str):
    '''Возвращает данные пользователя через токен'''
    if check_token(token) == True:
        name = token_to_name(token)
        return get_user(name)
    return 'invalid token'

def add_stat(token, stat, value):
    if check_token(token) == True:
        name = token_to_name(token)
        newvalue = int(get_var(name, stat)) + value
        set_var(name, stat, newvalue)
        return 'ok'
    return 'invalid token'

def add_presentation(token, theme):
    if check_token(token) == True:
        name = token_to_name(token)
        newvalue = get_var(name, 'allpresentations').append(theme)
        set_var(name, 'allpresentations', newvalue)
        return 'ok'
    return 'invalid token'

