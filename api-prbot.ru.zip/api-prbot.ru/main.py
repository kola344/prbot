# bot
import os.path
import shutil

import telebot
import time
import botdb as db

# libs
from replics import *
import requests
import json
from threading import Thread
import zipfile
# TOKEN
bot = telebot.TeleBot('6892246437:AAEmghBVr8NLRPdMJSiWo3bp82V-YfH0oew')
started = False

# commands
generationstatus = False
generation = {}
def generate_presentation(token, theme, countslides, add):
    global generation
    global generationstatus
    generationstatus = True
    print(True)
    try:
        if add == None:
            data = requests.get(f'http://api-prbot.ru/generate_presentation?token={token}&theme={theme}&countslides={countslides}', verify=False, timeout=500).text
            print(data)
        else:
            data = requests.get(f'http://api-prbot.ru/generate_presentation?token={token}&theme={theme}&countslides={countslides}&add={add}', verify=False, timeout=500).text
            print(data)
        generation = json.loads(data)
        print(generation)
        generationstatus = False
    except Exception as e:
        print(e)
        generationstatus = False
        generation = {'meta': {'error': 500}}

users = {}
class User:
    def __init__(self, chatid):
        self.chatid = chatid
        self.name = None
        self.password = None
        self.validate = None
        self.countslides = 5
        self.theme = None
        self.add = None
        self.menuid = None

# Очистка всех данных
# Получить свой айди
@bot.message_handler(commands=['myid'])
def myid(message):
    bot.send_message(message.chat.id, message.chat.id)

# Начало
@bot.message_handler(commands=['start'])
def stirt(message):
    if message.chat.type == 'private':
        if db.check_user(message.chat.id) == True:
            text, markup = menu()
            bot.send_message(message.chat.id, text, reply_markup=markup)
        else:
            print(f'Новый пользователь {message.chat.id}')
            text, markup = start()
            bot.send_message(message.chat.id, text, reply_markup=markup)

# messages
@bot.message_handler(content_types=['text'])
def reply(message):
    if message.chat.type == 'private':
        if db.check_user(message.chat.id) == False:
            if message.text == 'Регистрация':
                print(f'Пользователь выбирает регистрация')
                msg = bot.send_message(message.chat.id, '😄')
                time.sleep(3)
                bot.delete_message(message.chat.id, msg.id)

                msg = bot.send_message(message.chat.id, replic_regname, reply_markup=types.ReplyKeyboardRemove())
                bot.register_next_step_handler(msg, regname)
            elif message.text == 'Авторизация':
                print(f'Пользователь выбирает авторизацию')
                msg = bot.send_message(message.chat.id, '😄')
                time.sleep(3)
                bot.delete_message(message.chat.id, msg.id)

                msg = bot.send_message(message.chat.id, replic_authname)
                bot.register_next_step_handler(msg, authname)
            else:
                bot.send_message(message.chat.id, replic_commandnotfound)
                text, markup = start()
                bot.send_message(message.chat.id, text, reply_markup=markup)
        else:
            if message.text == 'Меню':
                text, markup = menu()
                bot.send_message(message.chat.id, text, reply_markup=markup)
            elif message.text == 'Аккаунт':
                text, markup = account(message.chat.id)
                bot.send_message(message.chat.id, text, reply_markup=markup)
            elif message.text == 'Я разработчик':
                text, markup, inlinemarkup = dev(message.chat.id)
                bot.send_message(message.chat.id, '⚙️', reply_markup=markup)
                time.sleep(1)
                bot.send_message(message.chat.id, text, reply_markup=inlinemarkup)
            elif message.text == 'Генерация':
                print(f'Пользователь {message.chat.id} хочет сгенерировать презентацию')
                users[message.chat.id] = User(message.chat.id)
                countslides = users[message.chat.id].countslides
                text, markup, inlinemarkup = genpr(countslides)
                text = text.replace('%seconds%', '50 секунд').replace('%theme%', 'Не выбрана')
                bot.send_message(message.chat.id, '✨', reply_markup=markup)
                msg = bot.send_message(message.chat.id, text, reply_markup=inlinemarkup)
                users[message.chat.id].menuid = msg.message_id
            else:
                bot.send_message(message.chat.id, replic_commandnotfound)
                text, markup = menu()
                bot.send_message(message.chat.id, text, reply_markup=markup)

def authname(message):
    users[message.chat.id] = User(message.chat.id)
    users[message.chat.id].name = message.text
    msg = bot.send_message(message.chat.id, replic_authpassword)
    bot.register_next_step_handler(msg, authpassword)

def authpassword(message):
    password = message.text
    name = users[message.chat.id].name
    try:
        data = json.loads(requests.get(f'https://api-prbot.ru/user?do=login&name={name}&password={password}', verify=False).text)
        error = data['meta']['error']
        if error == 103:
            msg = bot.send_message(message.chat.id, replic_authnotfound)
            bot.register_next_step_handler(msg, authname)
        elif error == 102:
            msg = bot.send_message(message.chat.id, replic_authinvalidpassword)
            bot.register_next_step_handler(msg, authpassword)
        else:
            bot.send_message(message.chat.id, '⚙️Авторизирую...')
            token = data['info']['token']
            db.add_user(message.chat.id, name, password, token)
            bot.send_message(message.chat.id, '✔️ Успешно!')
            text, markup = menu()
            bot.send_message(message.chat.id, text, reply_markup=markup)
    except Exception as e:
        print(e)
        msg = bot.send_message(message.chat.id, replic_autherror)
        bot.register_next_step_handler(msg, authname)

def regname(message):
    users[message.chat.id] = User(message.chat.id)
    users[message.chat.id].name = message.text

    msg = bot.send_message(message.chat.id, replic_regpassword)
    bot.register_next_step_handler(msg, regpassword)

def regpassword(message):
    users[message.chat.id].password = message.text

    msg = bot.send_message(message.chat.id, replic_regvalidate)
    bot.register_next_step_handler(msg, regvalidate)

def regvalidate(message):
    if users[message.chat.id].password != message.text:
        msg = bot.send_message(message.chat.id, replic_passvalid)
        bot.register_next_step_handler(msg, regpassword)
    else:
        users[message.chat.id].validate = message.text
        bot.send_message(message.chat.id, '⚙️Регистрирую...')

        name = users[message.chat.id].name
        password = users[message.chat.id].password
        validate = users[message.chat.id].validate
        try:
            data = json.loads(requests.get(f'https://api-prbot.ru/user?do=register&name={name}&password={password}&validate={validate}', verify=False).text)
            error = data['meta']['error']
            if error == 0:
                try:
                    data = json.loads(requests.get(f'https://api-prbot.ru/user?do=login&name={name}&password={password}', verify=False).text)
                    db.add_user(message.chat.id, name, password, data['info']['token'])
                    bot.send_message(message.chat.id, '✔️ Успешно!')
                    text, markup = menu()
                    bot.send_message(message.chat.id, text, reply_markup=markup)
                except Exception as e:
                    print(e)
                    msg = bot.send_message(message.chat.id, replic_regautherror)
                    bot.register_next_step_handler(msg, authname)

            elif error == 101:
                msg = bot.send_message(message.chat.id, replic_reguserexists)
                bot.register_next_step_handler(msg, regname)
        except Exception as e:
            print(e)
            msg = bot.send_message(message.chat.id, replic_regerror.replace('%error%', str(e)))
            bot.register_next_step_handler(msg, regname)

# callback
@bot.callback_query_handler(func=lambda call: True)
def callback(call):
    calls = str(call.data).split(sep='.')
    dir = calls[0]
    func = calls[1]
    value = calls[2]
    if dir == 'gen':
        if func == 'set':
            if value == 'theme':
                data = users[call.message.chat.id]
                bot.delete_message(call.message.chat.id, message_id=data.menuid)
                msg = bot.send_message(text=replic_gensettheme, chat_id=call.message.chat.id, reply_markup=types.ReplyKeyboardRemove())
                users[call.message.chat.id].menuid = msg.message_id
                bot.register_next_step_handler(msg, settheme)
            elif value == 'add':
                data = users[call.message.chat.id]
                bot.delete_message(call.message.chat.id, message_id=data.menuid)
                text, markup = replic_gensetadd()
                msg = bot.send_message(text=text, chat_id=call.message.chat.id, reply_markup=markup)
                users[call.message.chat.id].menuid = msg.message_id
                bot.register_next_step_handler(msg, setadd)
        elif func == 'slides':
            if value == 'minus':
                data = users[call.message.chat.id]
                countslides = data.countslides
                menuid = data.menuid
                theme = data.theme
                if countslides == 5:
                    bot.edit_message_text(text='⚠️Нельзя поставить меньше 5 слайдов', chat_id=call.message.chat.id, message_id=menuid)
                    time.sleep(3)
                    text, markup, inlinemarkup = genpr(5)
                    text = text.replace('%seconds%', '125 секунд').replace('%theme%', str(theme))
                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
                else:
                    countslides -= 1
                    users[call.message.chat.id].countslides = countslides
                    text, markup, inlinemarkup = genpr(countslides)
                    text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', str(theme))
                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)

            elif value == 'plus':
                    data = users[call.message.chat.id]
                    countslides = data.countslides
                    menuid = data.menuid
                    theme = data.theme
                    if countslides == 15:
                        bot.edit_message_text(text='⚠️Нельзя поставить больше 15 слайдов', chat_id=call.message.chat.id, message_id=menuid)
                        time.sleep(3)
                        text, markup, inlinemarkup = genpr(15)
                        text = text.replace('%seconds%', '375 секунд').replace('%theme%', str(theme))
                        bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
                    else:
                        countslides += 1
                        users[call.message.chat.id].countslides = countslides
                        text, markup, inlinemarkup = genpr(countslides)
                        text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', str(theme))
                        bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
        elif func == 'generate':
            if value == 'start':
                global generationstatus
                global generation
                if generationstatus == True:
                    data = users[call.message.chat.id]
                    menuid = data.menuid
                    countslides = data.countslides
                    theme = data.theme
                    bot.edit_message_text(text='⚠️ Кто-то уже генерирует презентацию. Попробуй позже.')
                    print(f'Пользователь {call.message.chat.id} не смог сгенерировать презентацию по причине очереди')
                    time.sleep(3)
                    text, markup, inlinemarkup = genpr(countslides)
                    text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', str(theme))
                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
                else:
                    token = db.get_var(call.message.chat.id, 'token')
                    data = users[call.message.chat.id]
                    menuid = data.menuid
                    countslides = data.countslides
                    theme = data.theme
                    add = data.add
                    print(f'Пользователь {call.message.chat.id} запускает генерацию на тему {theme}')
                    text = '✨ Начинаю генерацию'
                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid)
                    time.sleep(2)
                    Thread(target=generate_presentation, args=(token, theme, countslides, add)).start()
                    for i in range(countslides*10+1)[::-1]:
                        time.sleep(1)
                        text = f'⏱ Осталось приблизительно: {i} секунд.'
                        bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid)
                        if generationstatus == False:
                            error = generation['meta']['error']
                            if error != 0:
                                text, markup = generror(error)
                                bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid)
                                break
                            else:
                                break

                    if generationstatus == False:
                        error = generation['meta']['error']
                        if error == 0:
                            # presentation
                            try:
                                req = requests.get(generation['info']['url'], verify=False)
                                with open(f'saved/{theme}.pptx', 'wb') as f:
                                    f.write(req.content)
                            except Exception as e:
                                print(e)
                            # structure
                            try:
                                req = requests.get(generation['info']['structure'], verify=False)
                                with open(f'saved/{theme}.zip', 'wb') as f:
                                    f.write(req.content)
                            except Exception as e:
                                print(e)
                            # view
                            try:
                                req = requests.get(f'https://api-prbot.ru/view?theme={theme}?slide=index', verify=False)
                                with open(f'saved/{theme}.html', 'wb') as f:
                                    f.write(req.content)
                            except Exception as e:
                                print(e)
                            text, inlinemarkup = gensuccesfull(theme)
                            bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
                    else:
                        text = f'✨Осталось совсем чуть-чуть!'
                        bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid)
                        while True:
                            time.sleep(1)
                            if generationstatus == False:
                                error = generation['meta']['error']
                                if error != 0:
                                    text, markup = generror(error)
                                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid)
                                    break
                                else:
                                    #presentation
                                    try:
                                        req = requests.get(generation['info']['url'], verify=False)
                                        with open(f'saved/{theme}.pptx', 'wb') as f:
                                            f.write(req.content)
                                    except Exception as e:
                                        print(e)
                                    #structure
                                    try:
                                        req = requests.get(generation['info']['structure'], verify=False)
                                        with open(f'saved/{theme}.zip', 'wb') as f:
                                            f.write(req.content)
                                    except Exception as e:
                                        print(e)
                                    #view
                                    try:
                                        req = requests.get(f'https://api-prbot.ru/view?theme={theme}?slide=index', verify=False)
                                        with open(f'saved/{theme}.html', 'wb') as f:
                                            f.write(req.content)
                                    except Exception as e:
                                        print(e)
                                    text, inlinemarkup = gensuccesfull(theme)
                                    bot.edit_message_text(text=text, chat_id=call.message.chat.id, message_id=menuid, reply_markup=inlinemarkup)
                                    break
    elif dir == 'presentation':
        if func == 'get':
            theme = users[call.message.chat.id].theme
            if value == 'pptx':
                try:
                    bot.send_document(call.message.chat.id, open(f'saved/{theme}.pptx', 'rb'))
                except Exception as e:
                    print(e)
                    bot.send_message(call.message.chat.id, 'Не удалось найти файл')
            elif value == 'structure':
                try:
                    bot.send_document(call.message.chat.id, open(f'saved/{theme}.zip', 'rb'))
                except Exception as e:
                    print(e)
                    bot.send_message(call.message.chat.id, 'Не удалось найти файл')
            elif value == 'html':
                try:
                    bot.send_document(call.message.chat.id, open(f'saved/{theme}.html', 'rb'))
                except Exception as e:
                    print(e)
                    bot.send_message(call.message.chat.id, 'Не удалось найти файл')
            elif value == 'view':
                try:
                    try:
                        shutil.rmtree('bot')
                    except:
                        pass
                    with zipfile.ZipFile(f'saved/{theme}.zip') as zf:
                        zf.extractall('bot')

                    bot.send_message(call.message.chat.id, '⤵️')
                    path = f'bot/Generation/presentations/{theme}/'
                    bot.send_message(call.message.chat.id, f'<b>Презентация на тему</b>\n{theme}', parse_mode='html')
                    for i in range(1, 15):
                        if os.path.exists(f'{path}slide{i}.txt') == True:
                            with open(f'{path}slide{i}.txt') as f:
                                data = eval(f.read())
                                titletext = data['title']
                                maintext = data['text']
                                text = f'<b>{titletext}</b>\n{maintext}'
                                image = data['image']
                                if image == True:
                                    try:
                                        bot.send_photo(call.message.chat.id, open(f'{path}slide{i}.jpg', 'rb'), caption=text, parse_mode='html')
                                    except:
                                        bot.send_message(call.message.chat.id, text=text, parse_mode='html')
                                else:
                                    bot.send_message(call.message.chat.id, text=text, parse_mode='html')
                        else:
                            break
                except Exception as e:
                    print(e)
                    bot.send_message(call.message.chat.id, 'Не удалось найти файл')

def settheme(message):
    #req
    countslides = users[message.chat.id].countslides
    users[message.chat.id].theme = message.text
    text, markup, inlinemarkup = genpr(countslides)
    text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', message.text)
    bot.send_message(message.chat.id, '✨', reply_markup=markup)
    msg = bot.send_message(message.chat.id, text, reply_markup=inlinemarkup)
    users[message.chat.id].menuid = msg.message_id

def setadd(message):
    countslides = users[message.chat.id].countslides
    theme = users[message.chat.id].theme
    if message.text == 'Отмена':
        text, markup, inlinemarkup = genpr(countslides)
        text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', str(theme))
        bot.send_message(message.chat.id, '✨', reply_markup=markup)
        msg = bot.send_message(message.chat.id, text, reply_markup=inlinemarkup)
        users[message.chat.id].menuid = msg.message_id
    else:
        users[message.chat.id].add = message.text
        text, markup, inlinemarkup = genpr(countslides)
        text = text.replace('%seconds%', str(countslides*10)).replace('%theme%', str(theme))
        bot.send_message(message.chat.id, '✨', reply_markup=markup)
        msg = bot.send_message(message.chat.id, text, reply_markup=inlinemarkup)
        users[message.chat.id].menuid = msg.message_id


# polling
def starting():
    while True:
        try:
            global started
            if started == True:
                return 'already started'
            bot.polling(none_stop=True)
        except Exception as e:
            print(e)

