import Generation.slide as pr
import Generation.openai_chat as gpt
import os

def check_system() -> (bool, list):
    '''Проверяет состояние всех систем'''
    if os.path.exists('health') == False:
        os.mkdir('health')
    image_status = pr.image_search('Котик', 'health/status.jpg')
    invalid_tokens = gpt.check_health()
    return image_status, invalid_tokens

