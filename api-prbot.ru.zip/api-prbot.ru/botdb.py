from os.path import exists

#default = {name, password, token}
def check_user(userid):
    return exists(f'users/{userid}.txt')

def add_user(userid, name, password, token):
    if check_user(userid) == False:
        default = {'name': name, 'password': password, 'token': token}
        with open(f'users/{userid}.txt', 'w') as f:
            f.write(str(default))
            return True
    return False

def get_user(userid):
    return eval(open(f'users/{userid}.txt', 'r').read())

def get_var(userid, var):
    return get_user(userid)[var]

def set_var(userid, var, value):
    '''Устанавливает значение переменной'''
    with open(f'users/{userid}.txt', 'r') as f:
        data = eval(f.read())
    data[var] = value
    with open(f'users/{userid}.txt', 'w') as f:
        f.write(str(data))