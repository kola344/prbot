from telebot import types
import botdb as db

#registration
replic_regname = '😀 Начнем регистрацию.\n👤 Придумай логин'
replic_regpassword = '🙂 Супер!\n✏️ Придумай пароль'
replic_regvalidate = '😄 Отлично!\n👌 Подтверди свой пароль'
replic_passvalid = '😕 Пароли не совпадают.\n✏️ Придумай пароль'
replic_regerror = '☹️ Возникла ошибка регистрации на стороне сервера. Попробуй ещё раз.\n error: %error%\n👤 Придумай логин'
replic_reguserexists = '🙁 Такой пользователь уже существует. Зарегистрируйся заново, выбрав другое имя пользователя.\n👤 Придумай логин'
replic_regautherror = '🙁 Произошла внутренняя ошибка авторизации. Твой аккаунт создан, просто авторизируйся.\n👤 Введи логин'

#authorization
replic_authname = '😀 О, у тебя уже есть аккаунт!\n👤 Введи логин'
replic_authpassword = '🙂 Супер!\n✏️ Введи пароль'
replic_authnotfound = '🙁 Пользователь не найден. Попробуй ещё раз (введи логин) или зарегистрируйся'
replic_authinvalidpassword = '🙁 Неверный пароль. Введи пароль ещё раз или зарегистрируйся'
replic_autherror = '🙁 Произошла ошибка авторизации. Попробуй ещё раз.\n👤 Введи логин'

#command not found
replic_commandnotfound = '🤔 Я не нашел такой команды. Пожалуйста, используй меня, нажимая на кнопки.'

#start
def start():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    text = '👋Привет!\n🤖 Я - бот, который умеет генерировать презентации по одному лишь заголовку!\n👨‍💻Ты разработчик? У меня есть api, чтобы ты мог встраивать сервис в свои проекты!\n\nЗарегистрируйся или авторизируйся, если у тебя есть аккаунт.'
    btn1 = types.KeyboardButton('Регистрация')
    btn2 = types.KeyboardButton('Авторизация')
    markup.row(btn1)
    markup.row(btn2)
    return text, markup

#menu
def menu():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    text = 'Выбери действие'
    btn1 = types.KeyboardButton('Генерация')
    btn2 = types.KeyboardButton('Аккаунт')
    btn3 = types.KeyboardButton('Я разработчик')
    markup.row(btn2, btn3)
    markup.row(btn1)
    return text, markup

#account
def account(userid):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn = types.KeyboardButton('Меню')
    markup.add(btn)

    data = db.get_user(userid)
    name = data['name']
    password = data['password']
    token = data['token']

    text = f'👤 Данные аккаунта.\n{name}\nПароль: {password}\nТокен: {token}'

    return text, markup

#dev
def dev(userid):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn = types.KeyboardButton('Меню')
    markup.add(btn)

    inlinemarkup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton('Ссылка', url='api-prbot.ru/dev')
    inlinemarkup.row(btn1)

    token = db.get_user(userid)['token']
    text = f'🤔 Ты разработчик? У меня есть api, позволяющий встраивать сервис в твои проекты!\n🙂Через HTTP запросы ты можешь генерировать презентации.\n🔒Используй токен для получения доступа к api: {token}\nПодробнее ты можешь узнать, перейдя по ссылке ниже.'

    return text, markup, inlinemarkup

#generation
replic_gensettheme = '✏️ Напиши тему презентации'
def replic_gensetadd():
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn = types.KeyboardButton('Отмена')
    markup.add(btn)

    text = '✏️ Напиши, что ты хочешь добавить в презентацию.\n⚠️ Просьба не писать по типу "Измени структуру презентации", в противном случае презентация не сгененируется\n⚙️ Пример, что можно писать: "Вставь в два слайда смешные шутки"\n🤔Если ты не хочешь вставлять дополнительную информацию, нажми "Отмена"'

    return text, markup

def genpr(slides):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn = types.KeyboardButton('Меню')
    markup.add(btn)

    inlinemarkup = types.InlineKeyboardMarkup()
    theme = types.InlineKeyboardButton('Тема', callback_data='gen.set.theme')
    add = types.InlineKeyboardButton('Дополнительно', callback_data='gen.set.add')
    countslides = types.InlineKeyboardButton(str(slides), callback_data='gen.info.buttons')
    minus1 = types.InlineKeyboardButton('-1', callback_data='gen.slides.minus')
    plus1 = types.InlineKeyboardButton('+1', callback_data='gen.slides.plus')
    generate = types.InlineKeyboardButton('Сгенерировать', callback_data='gen.generate.start')
    inlinemarkup.row(theme)
    inlinemarkup.row(add)
    inlinemarkup.row(minus1, countslides, plus1)
    inlinemarkup.row(generate)

    text = '😄 Здесь ты можешь сгенерировать свою презентацию.\n⚙️Настрой необходимые тебе параметры для генерации.\n✏️Обязательно впиши тему презентации и выбери количество слайдов.\n➕Если ты хочешь добавить дополнительную информацию в свою презентацию (например, "Добавить слайд с опросом о том, как слушатели поняли презентацию"), впиши это в "Дополнительно"\n⏳️Время генерации зависит от количества слайдов.\n\n⏱️ Текущее приблизительное время генерации: %seconds%\n📄 Тема: %theme%'

    return text, markup, inlinemarkup

def genprmarkup(slides):
    inlinemarkup = types.InlineKeyboardMarkup()
    theme = types.InlineKeyboardButton('Выбрать тему', callback_data='gen.set.theme')
    add = types.InlineKeyboardButton('Дополнительно', callback_data='gen.set.add')
    countslides = types.InlineKeyboardButton(str(slides), callback_data='gen.info.buttons')
    minus1 = types.InlineKeyboardButton('-1', callback_data='gen.slides.minus')
    plus1 = types.InlineKeyboardButton('+1', callback_data='gen.slides.plus')
    generate = types.InlineKeyboardButton('Сгенерировать', callback_data='gen.generate.start')
    inlinemarkup.row(theme)
    inlinemarkup.row(add)
    inlinemarkup.row(minus1, countslides, plus1)
    inlinemarkup.row(generate)

    return inlinemarkup

#generrors
def generror(code):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
    btn = types.KeyboardButton('Меню')
    markup.add(btn)

    text = ''
    if code == 500:
        text = '⚠️ Возникла неизвестная ошибка при генерации презентации. Попробуй позже'
    elif code == 202:
        text = '⚠️ Структура презентации, полученная от ChatGPT, не позволяет сгенерировать презентацию. Попробуй ещё раз и измени дополнительную информацию о презентации, если она есть.'
    elif code == 203:
        text = '⚠️ Презентация генерируется другим пользователем. Попробуй позже'
    return text, markup

def gensuccesfull(theme):
    markup = types.InlineKeyboardMarkup()
    btn1 = types.InlineKeyboardButton('Получить .pptx', callback_data=f'presentation.get.pptx')
    btn2 = types.InlineKeyboardButton('Получить структуру', callback_data=f'presentation.get.structure')
    btn3 = types.InlineKeyboardButton('Предпросмотр в боте', callback_data=f'presentation.get.view')
    btn4 = types.InlineKeyboardButton('Получить HTML', callback_data=f'presentation.get.html')
    btn5 = types.InlineKeyboardButton('Предпросмотр в браузере', url=f'https://api-prbot.ru/view?theme={theme}')
    markup.row(btn1)
    markup.row(btn4)
    markup.row(btn2)
    markup.row(btn3)
    markup.row(btn5)
    text = f'✨Презентация сгенерирована!'
    return text, markup