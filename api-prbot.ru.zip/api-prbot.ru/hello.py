from flask import Flask, request, send_file, make_response
import start
from flask import render_template
import traceback
import sys
import os
import zipfile
import traceback
from threading import Thread
from main import starting

application = Flask(__name__)

users = {}

def generated_pr(token):
    global users
    try:
        users[token]['error'] = 0
        theme = users[token]['theme']
        countslides = users[token]['countslides']
        add = users[token]['add']
        if add == '':
            add = None
        data = start.generate_presentation(token=token, theme=theme, countslides=int(countslides), name=None, add=add)
        users[token]['status'] = 1
        users[token]['error'] = data['meta']['error']
    except Exception as e:
        users[token]['status'] = 1
        users[token]['error'] = 1

@application.errorhandler(404)
def page_not_found(e):
    return send_file('site/html/404.html')
    
@application.errorhandler(500)
def page_not_found(e):
    return send_file('site/html/500.html')

@application.route('/generators/<generator>')
def generatorr(generator):
    return send_file(f'site/html/{generator}.html')
    
@application.route('/askgenerate', methods=['POST'])
def askgeneratefunc():
    data = request.form
    token = request.cookies.get('token')
    question = data['question']
    
    if token == None or token == 'None':
        return send_file(f'site/html/accountreg.html')
    
    data = start.ask(token, question)
    with open(f'site/ask.html') as f:
        resp = f.read().replace('%text%', data['info']['text'])
        return resp

@application.route('/essaygenerate', methods=['POST'])
def essaygeneratefunc():
    data = request.form
    token = request.cookies.get('token')
    theme = data['theme']
    countwords = int(data['countwords'])
    
    if token == None or token == 'None':
        return send_file(f'site/html/accountreg.html')
        
    data = start.essay(token, theme, countwords)
    with open(f'site/ask.html') as f:
        resp = f.read().replace('%text%', data['info']['text'])
        return resp

@application.route('/abstractgenerate', methods=['POST'])
def abstractgeneratefunc():
    data = request.form
    token = request.cookies.get('token')
    theme = data['theme']
    
    if token == None or token == 'None':
        return send_file(f'site/html/accountreg.html')
        
    data = start.abstract(token, theme)
    with open(f'site/generatorsuccesfull.html') as f:
        resp = f.read().replace('%url%', f'https://api-prbot.ru/abstractdl?theme={theme}')
        return resp

@application.route('/abstractdl')
def downloadsbatrctfunc():
    theme = request.args.get('theme')
    return send_file(f'Generation/abstracts/{theme}.txt')

@application.route('/generators')
def generatorslist():
    return send_file('site/html/generators.html')

@application.route('/storage')
def storagefunc():
    try:
        with open(f'site/example.txt', 'r') as f:
            data = f.read()
        with open(f'Generation/generated.txt', 'r') as f:
            presentations = eval(f.read())
        with open(f'site/html/storage.html', 'r') as f:
            page = f.read()
        main = ''
        for i in presentations:
            main += data.replace('%theme%', i).replace('%countslides%', str(presentations[i]['countslides'])).replace('%url%', f'https://api-prbot.ru/download?presentation={i}').replace('%predurl%', f'https://api-prbot.ru/view?theme={i}').replace('%structure%', f'https://api-prbot.ru/download?structure={i}')
        return page.replace('%main%', main)
    except Exception as e:
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'
    
@application.route("/")
def hello():
    return send_file('site/html/index.html')

@application.route("/sitecss")
def sitecss():
    v = request.args.get('v')
    return send_file(f'site/css/{v}')
    
@application.route('/siteimages')
def siteimages():
    v = request.args.get('v')
    return send_file(f'site/images/{v}')

@application.route('/dev')
def sitedev():
    return send_file(f'site/html/dev.html')

@application.route('/agree')
def siteagree():
    return send_file(f'site/html/agree.html')
    
@application.route('/account')
def siteaccount():
    try:
        cookie = request.cookies.get('token')
        if cookie == None:
            return send_file(f'site/html/accountreg.html')
        else:
            data = start.user(do='stats', token=cookie)
            data = data['info']
            with open(f'site/html/account.html', 'r') as f:
                resp = f.read().replace('%username%', data['name']).replace('%password%', data['password']).replace('%token%', data['token'])
            return resp
    except Exception as e:
        return str(e)

@application.route('/accountreg', methods=['POST'])
def siteaccountreg():
    try:
        data = request.form
        username = data['username']
        password = data['password']
        validate = data['validate']
        if password != validate:
            with open(f'site/html/accountregerror.html', 'r') as f:
                resp = f.read().replace('%error%', 'Пароли не совпадают')
                return resp
        data = start.user(do='register', name=username, password=password, validate=validate)
        meta = data['meta']
        error = meta['error']
        if error == 101:
            with open(f'site/html/accountregerror.html', 'r') as f:
                resp = f.read().replace('%error%', 'Пользователь уже существует')
                return resp
        elif error == 0:
            data = start.user(do='login', name=username, password=password)
            data = data['info']
            token = data['token']
            with open(f'site/html/account.html', 'r') as f:
                text = f.read().replace('%username%', data['name']).replace('%password%', data['password']).replace('%token%', data['token'])
                resp = make_response(text)
                resp.set_cookie('token', token, max_age=30*24*60*60)
            return resp
    except Exception as e:
        return str(e)

@application.route('/authorization')
def authorizationn():
    return send_file(f'site/html/accountauth.html')

@application.route('/accountauth', methods=['POST'])
def siteaccountaith():
    try:
        data = request.form
        username = data['username']
        password = data['password']
        data = start.user(do='login', name=username, password=password)
        meta = data['meta']
        error = meta['error']
        if error == 102 or error == 103:
            with open(f'site/html/accountautherror.html', 'r') as f:
                    resp = f.read().replace('%error%', 'Неверное имя пользователя или пароль')
                    return resp
        elif error == 0:
            data = start.user(do='login', name=username, password=password)
            data = data['info']
            token = data['token']
            with open(f'site/html/account.html', 'r') as f:
                text = f.read().replace('%username%', data['name']).replace('%password%', data['password']).replace('%token%', data['token'])
                resp = make_response(text)
                resp.set_cookie('token', token, max_age=30*24*60*60)
            return resp
    except Exception as e:
        return str(e)

@application.route('/generation')
def sitegeneration():
    token = request.cookies.get('token')
    if token == None:
        return send_file(f'site/html/accountreg.html')
    return send_file(f'site/html/generation.html')

@application.route('/generate', methods=['POST', 'GET'])
def sitegeneratemethod():
    global users
    try:
        token=request.cookies.get('token')
        if request.method == 'POST':
            if token in users:
                if users[token]['error'] == -1:
                    print(token)
                    Thread(target=generated_pr, args=(token, )).start()
                    return send_file(f'site/html/gen.html')
                else:
                    if users[token]['status'] == 0:
                        return send_file(f'site/html/gen.html')
                    else:
                        error = users[token]['error']
                        theme = users[token]['theme']
                        del users[token]
                        if error == 200:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Количество слайдов меньше допустимого значения (5)')
                            return resp
                        elif error == 201:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Количество слайдов превышает допустимое значение (15)')
                            return resp
                        elif error == 202:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Структура плана презентации, полученного от ChatGPT, не позволяет сгенерировать презентацию')
                            return resp
                        elif error == 203:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Кто-то другой уже генерирует презентацию')
                            return resp
                        elif error == 1:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Произошла неизвестная ошибка. Попробуй ешё раз')
                            return resp
                        elif error == 104:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Неверный токен. Авторизируйся в другой аккаунт')
                            return resp
                        else:
                            with open(f'site/html/gensuccesfull.html', 'r') as f:
                                resp = f.read().replace('%url%', f'https://api-prbot.ru/download?presentation={theme}').replace('%predurl%', f'https://api-prbot.ru/view?theme={theme}').replace('%structure%', f'https://api-prbot.ru/download?structure={theme}')
                            return resp
            data = request.form
            theme = data['theme']
            countslides = data['countslides']
            add = data['add']
            users[token] = {'theme': theme, 'countslides': int(countslides), 'add': add, 'status': 0, 'error': -1}
            return send_file(f'site/html/gen.html')
        elif request.method == 'GET':
            if not token in users:
                with open(f'site/html/generror.html', 'r') as f:
                    resp = f.read().replace('%error%', f'В настоящее время ты не генерируешь презентацию. Твой токен: {token}')
                return resp
            else:
                if users[token]['error'] == -1:
                    Thread(target=generated_pr, args=(token, )).start()
                    return send_file(f'site/html/gen.html')
                else:
                    if users[token]['status'] == 0:
                        return send_file(f'site/html/gen.html')
                    else:
                        error = users[token]['error']
                        theme = users[token]['theme']
                        if error == 200:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Количество слайдов меньше допустимого значения (5)')
                            return resp
                        elif error == 201:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Количество слайдов превышает допустимое значение (15)')
                            return resp
                        elif error == 202:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Структура плана презентации, полученного от ChatGPT, не позволяет сгенерировать презентацию')
                            return resp
                        elif error == 203:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Кто-то другой уже генерирует презентацию')
                            return resp
                        elif error == 1:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Произошла неизвестная ошибка. Попробуй ешё раз')
                            return resp
                        elif error == 104:
                            with open(f'site/html/generror.html', 'r') as f:
                                resp = f.read().replace('%error%', 'Неверный токен. Авторизируйся в другой аккаунт')
                            return resp
                        else:
                            with open(f'site/html/gensuccesfull.html', 'r') as f:
                                resp = f.read().replace('%url%', f'https://api-prbot.ru/download?presentation={theme}').replace('%predurl%', f'https://api-prbot.ru/view?theme={theme}').replace('%structure%', f'https://api-prbot.ru/download?structure={theme}')
                            return resp
    
    except Exception as e:
        site_queue = ''
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'
@application.route('/user')
def user():
    try:
        do = request.args.get('do')
        name = request.args.get('name')
        token = request.args.get('token')
        password = request.args.get('password')
        validate = request.args.get('validate')
    
        return start.user(do=do, name=name, token=token, password=password, validate=validate)
    except Exception as e:
        return str(e) 

@application.route('/health')
def systemhealth():
    try:
        token = request.args.get('token')
        
        return start.check_systemhealth(token)
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'

@application.route('/generate_abstract')
def generator_abstract():
    try:
        token = request.args.get('token')
        theme = request.args.get('theme')
        
        return start.abstract(token, theme)
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'
        
@application.route('/gpt')
def generator_gpt():
    try:
        token = request.args.get('token')
        question = request.args.get('question')
        
        return start.ask(token, question)
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'


@application.route('/generate_essay')
def generator_essay():
    try:
        token = request.args.get('token')
        theme = request.args.get('theme')
        countwords = int(request.args.get('countwords'))
        
        return start.essay(token, theme, countwords)
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'

@application.route('/generate_presentation')
def presentation():
    try:
        token = request.args.get('token')
        theme = request.args.get('theme')
        countslides = request.args.get('countslides')
        name = request.args.get('name')
        add = request.args.get('add')
    
        return start.generate_presentation(token=token, theme=theme, countslides=int(countslides), name=name, add=add)
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'

@application.route('/generation_time')
def gentime():
    try:
        token = request.args.get('token')
        countslides = int(request.args.get('countslides'))
    
        return start.generation_time(token, int(countslides))
    except Exception as e:
        start.queue = 0
        err = 'Ошибка:\n' + traceback.format_exc()
        return err
        return f'error: {e}'

@application.route('/get_presentation')
def getpr():
    try:
        token = request.args.get('token')
        theme = request.args.get('theme')
    
        return start.get_presentation(token, theme)
    except Exception as e:
        start.queue = 0
        return str(e)

@application.route('/image')
def imageget():
    theme = request.args.get('theme')
    slide = request.args.get('slide')
    if os.path.exists(f'Generation/presentations/{theme}/slide{slide}.jpg') == True:
        return send_file(f'Generation/presentations/{theme}/slide{slide}.jpg')
    return 'Not found'

@application.route('/css')
def csss():
    try:
        theme = request.args.get('theme')
        slide = request.args.get('slide')
        if slide == 'title':
            return send_file(f'Generation/presentations/{theme}/view/title.css')
        else:
            return send_file(f'Generation/presentations/{theme}/view/slide{slide}.css')
    except Exception as e:
        return str(e)

@application.route('/view')
def view():
    try:
        theme = request.args.get('theme')
        alphabet = ['%20', '%2520']
        for i in alphabet:
            if i in theme:
                theme = theme.replace(i, ' ')
        slide = request.args.get('slide')
        if slide == None or slide == 'None':
            return send_file(f'Generation/presentations/{theme}/view/title.html')
        elif slide == 'index':
            return send_file(f'Generation/presentations/{theme}/index.html')
        elif slide == 'title' or slide == '0':
            return send_file(f'Generation/presentations/{theme}/view/title.html')
        else:
            return send_file(f'Generation/presentations/{theme}/view/slide{slide}.html')
    except Exception as e:
        return str(e)

@application.route('/background')
def backview():
    theme = request.args.get('theme')
    return send_file(f'Generation/presentations/{theme}/background.png')

@application.route('/download')
def doload():
    try:
        theme = request.args.get('presentation')
        structure = request.args.get('structure')
        if os.path.exists(f'Generation/presentations/{theme}') == True:
            return send_file(f'Generation/presentations/{theme}/{theme}.pptx')
        if os.path.exists(f'Generation/presentations/{structure}') == True:
            files = os.listdir(f"Generation/presentations/{structure}")
            archive = "archive.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                for file in files:
                    zf.write(f'Generation/presentations/{structure}/{file}')
            return send_file(f'archive.zip')
        return 'Not Found'
    except Exception as e:
        return str(e) + '8'

@application.route('/startbot')
def startingtgbotfunc():
    Thread(target=starting).start()
    return "true"
    
if __name__ == "__main__":
   application.run(host='0.0.0.0', debug=True)