#Подбор информации о слайде. Тип расположения, скачивание картинки и тд
import Generation.config as config
import requests as r
import os
import Generation.openai_chat as gpt
from Generation.config import path, mainpath, apikey, cx, google_search
import requests
import json

def image_search(text: str, name: str) -> bool:
    '''Ищет изображения по запросу и сохраняет изображения в папку имени презентации
    Возвращает результат поиска True/False'''
    try:
        res = google_search.replace('%query%', text).replace('%key%', apikey).replace('%cx%', cx)
        result = json.loads(requests.get(res).text)
        responses = result['items']#[0]['link']
        for i in responses:
            try:
                url = i['link']
                img = r.get(url, timeout=3)
                img_file = open(name, 'wb')
                img_file.write(img.content)
                img_file.close()
                print(f'image url: {url}')
                return True
            except Exception as e:
                print(e)
        return False
    except:
        return False

def title_generate(theme: str, name: str):
    '''Генерирует структуру титульного листа'''
    #Создаем файлы с темой и автором презентации.
    with open(f'{mainpath}{path}presentations/{theme}/titlemain.txt', 'w') as f:
        f.write(f'Презентация на тему {theme}')
    with open(f'{mainpath}{path}presentations/{theme}/titletext.txt', 'w') as f:
        f.write(f'Выполнил {name}')




def slide_generate(theme: str, text: str, number: int) -> None:
    '''Генерирует структуру каждого слайда и сохраняет информацию о нем в папке с именем презентации'''

    promt = config.promtslide.replace('%theme%', theme).replace('%slide%', text) #Отправляем запрос в ChatGPT
    answer = gpt.do_request(promt).replace('\n\n', '\n')[1:] #Убираем двойные переносы
    print(f'\nОтвет ChatGPT по генерации слайда {number}.\n{answer}')
    with open(f'{mainpath}{path}presentations/{theme}/slide{number}.txt', 'w') as f:
       f.write(answer) #Записываем текст в файл
    '''==========='''
    # with open(f'{mainpath}{path}presentations/{theme}/slide{number}.txt') as f:
    #     data = eval(f.read())
    #     answer = 'image' + '\n' + data['text']
    '''==========='''

    indscob = answer.index(')')
    if answer[indscob+1] == ' ' or answer[indscob+2] == ' ':
        answer = answer.replace(')', '\n', 1)
    answersplit = answer.split('\n')
    while answersplit[0] == '':
        answersplit = answersplit[1:]
    print(f"Ищем картинку... {answersplit}")

    #Берем картинку из ответа и ищем её
    print(f'image до сплита {answersplit}')
    image = answersplit[0].replace('(', '').replace(')', '')
    print(f'сплитнутый image\n {image}')
    status = image_search(image, f'{mainpath}{path}presentations/{theme}/slide{number}.jpg')
    print(f'Нашли или нет {status}')
    '''==========='''
    # status = os.path.exists(f'{path}presentations/{theme}/slide{number}.jpg')
    '''==========='''
    print('Ансвер без картинки:')
    #Преобразуем файл и в виде словаря записываем информацию о слайде в файл
    answer = '\n'.join(answersplit[1:])
    with open(f'{mainpath}{path}presentations/{theme}/slide{number}.txt', 'w') as f:
        a = '0123456789'
        ind = -1
        for i, b in enumerate(text):
            if b in a:
                ind = i
                break

        text = text[ind+2:]
        data = {'title': text, 'text': answer, 'image': status}
        f.write(str(data))

