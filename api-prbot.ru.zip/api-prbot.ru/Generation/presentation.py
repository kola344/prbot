#Генерация презентации
import random
import json
import shutil

import Generation.config as config
import Generation.slide as slide
import Generation.openai_chat as gpt
import os
import time
import Generation.htmlgen as htmlgen
from Generation.config import path, mainpath

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_PARAGRAPH_ALIGNMENT, MSO_VERTICAL_ANCHOR
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_AUTO_SHAPE_TYPE
from pptx.enum.dml import MSO_THEME_COLOR_INDEX

def generate_slides(theme: str, slides: int, name: str, add: str = None) -> str:
    '''Генерирует презентацию и сохраняет её в виде файла
    presentations/{theme}/{theme}.pptx
    Возвращает результат работы функции'''

    info = 'ok'

    #check generated
    with open(f'{mainpath}{path}generated.txt') as f:
        meta = eval(f.read())
    if theme in meta:
        data = meta[theme]
        if data['add'] == add and data['countslides'] == slides:
            return 'ok'

    if slides > 15:
        return 'slides count error'
    #Первый слайд должен быть титульным
    slides -= 1

    promt = config.promt.replace('%theme%', theme).replace('%count%', str(slides)) # Отправляем запрос на генерацию плана
    if add != None:
        promt += config.promtplus.replace('%info%', add)
    answer = gpt.do_request(promt).replace('\n\n', '\n') # Убираем двойной перенос строки
    print(f'Ответ ChatGPT по плану: \n{answer}') #log
    if os.path.exists(f'{mainpath}{path}presentations/{theme}') == False:
       os.mkdir(f'{mainpath}{path}presentations/{theme}') #Создаем папку с презентацией
    with open(f'{mainpath}{path}presentations/{theme}/plan.txt', 'w') as f:
       f.write(answer) #Записываем план презентации
    '''==========='''
    # with open(f'{mainpath}{path}presentations/{theme}/plan.txt') as f:
    #     answer = f.read().replace('\n\n', '\n')
    '''==========='''

    #Считаем количество сгенерированных слайдов по плану и сверяем с количеством, которое необходимо сгенерировать
    countslides = answer.count('\n') #
    if countslides != slides - 1:
        info = 'ok. slides != slides_gpt'

    answer = answer[2:].split('\n') #Кидаем в массив каждый элемент плана
    if answer[0] == '':
        answer = answer[1:] #Если вместо фона первый элемент массива оказался пустым, убираем его
    background = answer[0] #Присваем фону описание от ChatGPT
    answer = answer[1:] #Убираем из массива плана фон

    #check structure
    alphabet = '123456789'
    for i in answer:
        if i[0] not in alphabet:
            return 'invalid structure'

    #Гененируем титульный слайд
    status = slide.title_generate(theme, name)
    if status != 'ok':
        info = 'ok. background error'

    #Генерируем презентацию и присваиваем макеты
    root = Presentation()

    blank_slide = root.slide_layouts[6]

    #Устанавливаем цветовую гамму
    colors = ['gray', 'white', 'blue', 'green', 'yellow']
    color = random.choice(colors)

    with open(f'{mainpath}{path}colors/colors.json', 'r') as f:
        data = json.loads(f.read())[color]
    background = f'{mainpath}{path}colors/{data["background"]}'
    titletext = data['titletext']
    maintext = data['maintext']
    block = data['block']

    shutil.copy(f'{mainpath}{path}colors/{data["background"]}', f'{mainpath}{path}presentations/{theme}')
    os.rename(f'{mainpath}{path}presentations/{theme}/{data["background"]}', f'{mainpath}{path}presentations/{theme}/background.png')

    #Генерируем титульный слайд
    slid = root.slides.add_slide(blank_slide)
    slid.shapes.add_picture(background, Inches(0), Inches(0), root.slide_width, root.slide_height)

    slid_width = root.slide_width
    slid_height = root.slide_height
    left = (slid_width - Inches(4)) / 2
    top = (slid_height - Inches(2)) / 2
    width = Inches(4)
    height = Inches(2)
    text_box = slid.shapes.add_textbox(left, top, width, height)
    text_frame = text_box.text_frame
    p = text_frame.add_paragraph()
    p.text = f'Презентация на тему\n{theme}'
    p.alignment = PP_PARAGRAPH_ALIGNMENT.CENTER
    p.font.size = Pt(32)
    p.font.bold = True
    p.font.color.rgb = RGBColor(maintext[0], maintext[1], maintext[2])

    structtypes = {'color': color}
    for i in range(1, countslides):
        '''==========='''
        '''==========='''
        text = answer[i-1] #Берем первый слайд из массива с планом
        print(f'Генерация слайда {i}. Запрос для ChatGPT: {text}') #log
        slide.slide_generate(theme, text, i) #Генерируем слайд

        with open(f'{mainpath}{path}presentations/{theme}/slide{i}.txt') as f:
            data = eval(f.read()) #Читаем информацию о сгенерированном слайде

        title = data['title'] #Заголовок слайда
        text = data['text'] #Текст слайда
        image = data['image'] #Информация (1,0) о наличии картинки на слайде

        ### titletext - преобразование заголовка слайда ###
        #Если заголовок получился вида => "Введение: основная информация" <= убираем лишнее, оставляя только "Введение"
        alphabet = ':(.,'
        for _ in alphabet:
            if _ in title:
                title = title[:title.index(_)]
        print(title)

        #Выбор шаблона
        templates = ['block', 'noblock']
        template = random.choice(templates)
        structtypes[i] = template
        slid = root.slides.add_slide(blank_slide)
        slid.shapes.add_picture(background, Inches(0), Inches(0), root.slide_width, root.slide_height)
        if template == 'noblock':
            # TITLE
            # Расположение блока
            width = root.slide_width
            height = Inches(1)
            left = top = Inches(0)
            rectangle = slid.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.RECTANGLE, left, top, width, height)

            rectangle.fill.solid()
            rectangle.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
            rectangle.line.fill.solid()
            rectangle.line.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
            shape = rectangle.text_frame.paragraphs[0]
            shape.alignment = PP_PARAGRAPH_ALIGNMENT.CENTER
            shape.text = title
            if len(title) < 29:
                shape.font.size = Pt(40)
            elif len(title) > 28 and len(title) < 38:
                shape.font.size = Pt(32)
            elif len(title) > 37 and len(title) < 43:
                shape.font.size = Pt(28)
            elif len(title) > 42:
                shape.font.size = Pt(24)
            shape.font.bold = True

            fill = shape.font.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
            fill.gradient()
            fill.gradient_stops[0].color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
            fill.gradient_stops[1].color.rgb = RGBColor(titletext[1][0], titletext[1][1], titletext[1][2])

            # TEXT
            top = Inches(1)
            left = Inches(0.2)
            width = Inches(9.6)
            height = root.slide_height - Inches(4)
            textBox = slid.shapes.add_textbox(left, top, width, height)
            tf1 = textBox.text_frame
            tf1.word_wrap = True
            p = tf1.paragraphs[0]
            p.text = text
            p.font.size = Pt(24)
            p.font.color.rgb = RGBColor(maintext[0], maintext[1], maintext[2])
            # IMAGE AND NEXT
            try:
                img_path = f'{mainpath}{path}presentations/{theme}/slide{i}.jpg'
                top = Inches(4)
                left = Inches(2.5)
                shape = slid.shapes.add_picture(img_path, left, top)
                shape.width = Inches(5)
                shape.height = Inches(3.5)
            except:
                pass
        else:
            if image == True:
                # TITLE
                # Расположение блока
                if len(title) > 13:
                    width = Inches(9.5)
                else:
                    width = Inches(4.7)
                height = Inches(1.1)
                left = Inches(0.2)
                top = Inches(0.2)
                # Блок
                rectangle = slid.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, left, top, width, height)
                rectangle.adjustments[0] = 0.2
                shape = rectangle.text_frame.paragraphs[0]
                shape.alignment = PP_PARAGRAPH_ALIGNMENT.CENTER
                shape.text = title
                if len(title) < 29:
                    shape.font.size = Pt(40)
                elif len(title) > 28 and len(title) < 38:
                    shape.font.size = Pt(32)
                elif len(title) > 37 and len(title) < 43:
                    shape.font.size = Pt(28)
                elif len(title) > 42:
                    shape.font.size = Pt(24)
                shape.font.bold = True

                fill = shape.font.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
                fill.gradient()
                fill.gradient_stops[0].color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
                fill.gradient_stops[1].color.rgb = RGBColor(titletext[1][0], titletext[1][1], titletext[1][2])

                # Цвет и окраска
                rectangle.fill.solid()
                rectangle.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
                rectangle.line.fill.solid()
                rectangle.line.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])

                # TEXT
                # Расположение блока
                width = Inches(4.7)
                height = Inches(5.8)
                left = Inches(0.2)
                top = Inches(1.5)
                # Блок
                rectangle = slid.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, left, top, width, height)
                rectangle.adjustments[0] = 0.05
                rectangle.text_frame.vertical_anchor = MSO_VERTICAL_ANCHOR.TOP
                shape = rectangle.text_frame.paragraphs[0]
                shape.alignment = PP_PARAGRAPH_ALIGNMENT.LEFT
                shape.text = text
                shape.space_before = 0
                shape.font.size = Pt(20)
                shape.font.color.rgb = RGBColor(maintext[0], maintext[1], maintext[2])
                # цвет и обводка
                rectangle.fill.solid()
                rectangle.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
                rectangle.line.fill.solid()
                rectangle.line.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])

                # IMAGE
                try:
                    img_path = f'{mainpath}{path}presentations/{theme}/slide{i}.jpg'
                    top = Inches(2.3)
                    left = Inches(5.2)
                    shape = slid.shapes.add_picture(img_path, left, top)
                    shape.width = Inches(4.5)
                    shape.height = Inches(3.5)
                except:
                    pass
            else:
                # TITLE
                # Расположение блока
                if len(title) > 13:
                    width = Inches(9.5)
                else:
                    width = Inches(4.7)
                height = Inches(1.1)
                left = (root.slide_width - width) / 2
                top = Inches(0.2)
                # Блок
                rectangle = slid.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, left, top, width, height)
                rectangle.adjustments[0] = 0.2
                shape = rectangle.text_frame.paragraphs[0]
                shape.alignment = PP_PARAGRAPH_ALIGNMENT.CENTER
                shape.text = title
                if len(title) < 29:
                    shape.font.size = Pt(40)
                elif len(title) > 28 and len(title) < 38:
                    shape.font.size = Pt(32)
                elif len(title) > 37 and len(title) < 43:
                    shape.font.size = Pt(28)
                elif len(title) > 42:
                    shape.font.size = Pt(24)
                shape.font.bold = True

                fill = shape.font.fill
                fill.solid()
                fill.fore_color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
                fill.gradient()
                fill.gradient_stops[0].color.rgb = RGBColor(titletext[0][0], titletext[0][1], titletext[0][2])
                fill.gradient_stops[1].color.rgb = RGBColor(titletext[1][0], titletext[1][1], titletext[1][2])

                # Цвет и окраска
                rectangle.fill.solid()
                rectangle.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
                rectangle.line.fill.solid()
                rectangle.line.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])

                # TEXT
                # Расположение блока
                width = Inches(9.6)
                height = Inches(4)
                left = Inches(0.2)
                top = Inches(1.5)
                # Блок
                rectangle = slid.shapes.add_shape(MSO_AUTO_SHAPE_TYPE.ROUNDED_RECTANGLE, left, top, width, height)
                rectangle.adjustments[0] = 0.05
                rectangle.text_frame.vertical_anchor = MSO_VERTICAL_ANCHOR.TOP
                shape = rectangle.text_frame.paragraphs[0]
                shape.alignment = PP_PARAGRAPH_ALIGNMENT.LEFT
                shape.text = text
                shape.space_before = 0
                shape.font.size = Pt(20)
                shape.font.color.rgb = RGBColor(maintext[0], maintext[1], maintext[2])
                # цвет и обводка
                rectangle.fill.solid()
                rectangle.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])
                rectangle.line.fill.solid()
                rectangle.line.fill.fore_color.rgb = RGBColor(block[0], block[1], block[2])

    #Сохраняем полученную презентацию
    root.save(f'{mainpath}{path}presentations/{theme}/{theme}.pptx')
    with open(f'{mainpath}{path}generated.txt') as f:
        meta = eval(f.read())
    meta[theme] = {'add': add, 'countslides': slides+1}
    with open(f'{mainpath}{path}generated.txt', 'w') as f:
        f.write(str(meta))

    #Делаем предпросмотр
    colortype = [block, titletext, maintext]
    htmlgen.html_generator(countslides, theme, structtypes, colortype)

    return info
