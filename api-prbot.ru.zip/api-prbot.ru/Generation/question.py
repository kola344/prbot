import Generation.openai_chat as gpt
from Generation.config import essay_promt, essay_promtplus

def ask_gpt(question):
    return gpt.do_request(question)

def essay(theme, countwords, add):
    promt = essay_promt.replace('%theme%', theme).replace('%countwords%', str(countwords))
    if add != None and add != '':
        promt += essay_promtplus.replace('%info%', add)
    return gpt.do_request(promt)