import Generation.openai_chat as gpt
from Generation.config import report_promt, report_promttext, path, mainpath

def abstract(theme):
    try:
        with open(f'{mainpath}{path}abstracts/{theme}.txt', 'w') as f:
            promt = report_promt.replace('%theme%', theme)
            answer = gpt.do_request(promt)
            plan = answer.split('\n')
            while plan[0] == '':
                plan = plan[1:]
            print(plan)
            for i in plan:
                promt = report_promttext.replace('%title%', i).replace('%theme%', theme)
                answer = gpt.do_request(promt)
                print(f'{i}{answer}\n\n')
                f.write(f'{i}{answer}\n\n')
        return True
    except:
        return False

