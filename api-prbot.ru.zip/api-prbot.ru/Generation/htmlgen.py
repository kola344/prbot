from Generation.config import path, mainpath
import os

def html_generator(countslides: int, theme: str, structtypes: dict, colortype: list) -> bool:
    '''Генерирует HTML-страницу предпросмотра презентации'''
    try:
        block, titletext, maintext = colortype[0], colortype[1], colortype[2]
        blockr, blockg, blockb = block[0], block[1], block[2]
        titletextr, titletextg, titletextb = titletext[1][0], titletext[1][1], titletext[1][2]
        maintextr, maintextg, maintextb = maintext[0], maintext[1], maintext[2]

        if os.path.exists(f'{mainpath}{path}/presentations/{theme}/view') == False:
            os.mkdir(f'{mainpath}{path}/presentations/{theme}/view')
        with open(f'{mainpath}{path}templates/title.html', 'r') as ht:
            htmldata = ht.read().replace('%csslink%', f'https://api-prbot.ru/css?theme={theme}&slide=title').replace('%theme%', theme).replace('%nextslide%', f'https://api-prbot.ru/view?theme={theme}&slide=1').replace('%slide%', '1').replace('%countslides%', str(countslides))
        with open(f'{mainpath}{path}templates/title.css', 'r') as ct:
            cssdata = ct.read().replace('%backgroundurl%', f'https://api-prbot.ru/background?theme={theme}').replace('%maintext%', f'{maintextr}, {maintextg}, {maintextb}')
        with open(f'{mainpath}{path}presentations/{theme}/view/title.html', 'w') as html:
            html.write(htmldata)
        with open(f'{mainpath}{path}presentations/{theme}/view/title.css', 'w') as css:
            css.write(cssdata)

        for i in range(1, countslides):
            with open(f'{mainpath}{path}presentations/{theme}/slide{i}.txt', 'r') as sel:
                    data = eval(sel.read())
                    title = data['title']
                    text = data['text'].replace('\n', '<br>')
                    image = data['image']

            struct = structtypes[i]
            if image == True:
                imageneed = 'image'
            else:
                imageneed = 'noimage'
            with open(f'{mainpath}{path}templates/{struct}_{imageneed}.html', 'r') as ht:
                htmldata = ht.read()
            with open(f'{mainpath}{path}templates/{struct}_{imageneed}.css', 'r') as ct:
                cssdata = ct.read()

            htmldata = htmldata.replace('%csslink%', f'https://api-prbot.ru/css?theme={theme}&slide={i}').replace('%title%', title).replace('%text%', text).replace('%backslide%', f'https://api-prbot.ru/view?theme={theme}&slide={i-1}').replace('%nextslide%', f'https://api-prbot.ru/view?theme={theme}&slide={i+1}').replace('%slide%', str(i+1)).replace('%countslides%', str(countslides))
            if i == countslides - 1:
                htmldata = htmldata.replace(f"<div class='next'><a href='https://api-prbot.ru/view?theme={theme}&slide={i+1}'>>></a></div>", '')
            if 'slide0' in htmldata:
                htmldata = htmldata.replace('slide0', 'title')

            cssdata = cssdata.replace('%backgroundurl%', f'https://api-prbot.ru/background?theme={theme}').replace('%blockcolor%', f'{blockr}, {blockg}, {blockb}').replace('%titlecolor%', f'{titletextr}, {titletextg}, {titletextb}').replace('%textcolor%', f'{maintextr}, {maintextg}, {maintextb}')

            if image == True:
                htmldata = htmldata.replace('%image%', f'https://api-prbot.ru/image?theme={theme}&slide={i}')

            with open(f'{mainpath}{path}presentations/{theme}/view/slide{i}.html', 'w') as html:
                html.write(htmldata)
            with open(f'{mainpath}{path}presentations/{theme}/view/slide{i}.css', 'w') as css:
                css.write(cssdata)

        with open(f'{mainpath}{path}presentations/{theme}/index.html', 'w') as f:
            f.write(f'<meta charset="utf-8">\n\n<title>Предпросмотр</title>\n<h3>Презентация на тему</h3>\n<p>{theme}</p>\n<hr>\n\n')
            for i in range(1, countslides):
                with open(f'{mainpath}{path}presentations/{theme}/slide{i}.txt', 'r') as sel:
                    data = eval(sel.read())
                    title = data['title']
                    text = data['text'].replace('\n', '<br>')
                    image = data['image']

                    f.write(f'<h2>{title}</h2>\n<p>{text}</p>\n')
                    if image == True:
                        f.write(f'<img src="https://api-prbot.ru/image?theme={theme}&slide={i}" height=300>\n')
                    f.write('<hr>\n')
        return True
    except Exception as e:
        print(e)
        return False
