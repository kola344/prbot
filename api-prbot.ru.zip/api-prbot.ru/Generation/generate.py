#program
import Generation.presentation as presentation
import Generation.requestss as requestss

#print - log
def give_info(theme: str, slides: int, name: str = '', add: str = None) -> (bool, str, str):
    '''Отправляет запрос на генерацию презентации и возвращает статус генерации'''
    return presentation.generate_slides(theme, slides, name, add)

#status, reason, info = give_info('Дверь', 5, '')

