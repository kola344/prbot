import json
import requests
from Generation.config import mainpath, path

with open(f'{mainpath}{path}api_keys.json') as f:
    keys = json.loads(f.read())

#Сделать запрос для ChatGPT. Возвращает готовый текст.
def do_request(promt: str) -> str:
    '''Принимает запрос для ChatGPT и возвращает ответ в виде текста'''
    for i in keys:
        try:
            url = 'https://kola344.pythonanywhere.com/gpt'
            data = {'token': i, 'text': promt}
            response = requests.post(url, json=data)
            if response.text == 'balance error':
                print('check balance')
                continue
            elif response.text == 'error' or 'error: ' in response.text:
                print(response.text)
                continue
            else:
                return response.text
        except Exception as e:
            continue

def check_health() -> list:
    '''Проверяет статус токенов'''
    invalids = []
    for i in keys:
        try:
            url = 'https://kola344.pythonanywhere.com/gpt'
            data = {'token': i, 'text': 'Привет'}
            response = requests.post(url, json=data)
            if response.text == 'balance error':
                invalids.append(i)
                print('check balance')
                continue
        except Exception as e:
            continue
    return invalids